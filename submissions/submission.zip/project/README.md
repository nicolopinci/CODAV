# CODAV
COVID Data Analyzer and Visualizer

In order to run the tool, first install the requirements (pip install -r requirements.txt), then run python app.py, replacing app.py with the complete path of the file.

You should upload the 20201125.csv file for the COVID dataset and the covid_impact_education.csv file for the education. You can also choose more recent files for the datasets, as long as they have at least the same columns as the proposed ones.